import React from "react";

export const Women = () => {
  return (
    <div className="text-center text-[100px] font-bold grid place-items-center h-screen">
      Women
      <span className="text-2xl font-bold">Working</span>
    </div>
  );
};
