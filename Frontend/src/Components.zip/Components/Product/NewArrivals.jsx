import React from "react";

export const NewArrivals = () => {
  return (
    <div className="text-center text-[100px] font-bold grid place-items-center h-screen">
      NewArrivals
      <span className="text-2xl font-bold">Working</span>
    </div>
  );
};
